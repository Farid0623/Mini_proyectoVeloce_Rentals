package repository.impl.vehicle;

public class VehicleRepositoryJdbcImpl {

}
